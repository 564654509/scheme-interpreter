/*
  Copyright (c) 2014 Xianfei Shen
  All rights reserved.

  Permission is hereby granted, without written agreement and without
  license or royalty fees, to use, copy, modify, and distribute this
  software and its documentation for any purpose, provided that the
  above copyright notice and the following two paragraphs appear in
  all copies of this software.
 
  IN NO EVENT SHALL BRENT BENSON BE LIABLE TO ANY PARTY FOR DIRECT,
  INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
  OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF BRENT
  BENSON HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

  BRENT BENSON SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT
  NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
  FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER
  IS ON AN "AS IS" BASIS, AND BRENT BENSON HAS NO OBLIGATION TO
  PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
  MODIFICATIONS.
*/

#ifndef _NUMBER_H
#define _NUMBER_H

#include "scheme.h"

extern scheme_object *num_add(const scheme_object *obj);


extern scheme_object *num_sub(const scheme_object *obj);


extern scheme_object *num_mul(const scheme_object *obj);


extern scheme_object *num_div(const scheme_object *obj);


extern inline scheme_object *num_mod(const scheme_object *obj);


extern scheme_object *num_gcd(const scheme_object *obj);


extern scheme_object *num_lcm(const scheme_object *obj);


extern inline scheme_object *num_abs(const scheme_object *obj);


extern scheme_object *num_max(const scheme_object *obj);


extern scheme_object *num_min(const scheme_object *obj);


extern inline scheme_object *num_floor(const scheme_object *obj);


extern inline scheme_object *num_round(const scheme_object *obj);


extern inline scheme_object *num_ceiling(const scheme_object *obj);


extern inline scheme_object *num_truncate(const scheme_object *obj);


extern inline scheme_object *num_expt(const scheme_object *obj);


extern inline scheme_object *num_denom(const scheme_object *obj);


extern inline scheme_object *num_numer(const scheme_object *obj);


extern inline scheme_object *num_real(const scheme_object *obj);


extern inline scheme_object *num_image(const scheme_object *obj);


extern inline scheme_object *num_quotient(const scheme_object *obj);


extern inline scheme_object *num_rem(const scheme_object *obj);


extern inline const scheme_object *num_eq(const scheme_object *obj);


extern inline const scheme_object *num_le(const scheme_object *obj);


extern inline const scheme_object *num_lt(const scheme_object *obj);


extern inline const scheme_object *num_ge(const scheme_object *obj);


extern inline const scheme_object *num_gt(const scheme_object *obj);


extern inline const scheme_object *num_pred_number(const scheme_object *obj);


extern inline const scheme_object *num_pred_complex(const scheme_object *obj);


extern inline const scheme_object *num_pred_real(const scheme_object *obj);


extern inline const scheme_object *num_pred_rational(const scheme_object *obj);


extern inline const scheme_object *num_pred_integer(const scheme_object *obj);


extern inline const scheme_object *num_pred_zero(const scheme_object *obj);


extern inline const scheme_object *num_pred_positive(const scheme_object *obj);


extern inline const scheme_object *num_pred_negative(const scheme_object *obj);


extern inline const scheme_object *num_pred_odd(const scheme_object *obj);


extern inline const scheme_object *num_pred_even(const scheme_object *obj);


extern inline const scheme_object *num_pred_exact(const scheme_object *obj);


extern inline const scheme_object *num_pred_inexact(const scheme_object *obj);


extern inline const scheme_object *num_sqrt(const scheme_object *obj);


extern inline scheme_object *num_exp(const scheme_object *obj);


extern inline scheme_object *num_log(const scheme_object *obj);


extern inline scheme_object *num_sin(const scheme_object *obj);


extern inline scheme_object *num_cos(const scheme_object *obj);


extern inline scheme_object *num_tan(const scheme_object *obj);


extern inline scheme_object *num_asin(const scheme_object *obj);


extern inline scheme_object *num_acos(const scheme_object *obj);


extern inline scheme_object *num_atan(const scheme_object *obj);


extern scheme_object *num_number_to_string(const scheme_object *obj);


extern scheme_object *num_string_to_string(const scheme_object *obj);


extern scheme_object *num_exact_to_inexact(const scheme_object *obj);


extern scheme_object *num_inexact_to_exact(const scheme_object *obj);

#endif
