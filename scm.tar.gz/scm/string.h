/*
  Copyright (c) 2014 Xianfei Shen
  All rights reserved.

  Permission is hereby granted, without written agreement and without
  license or royalty fees, to use, copy, modify, and distribute this
  software and its documentation for any purpose, provided that the
  above copyright notice and the following two paragraphs appear in
  all copies of this software.
 
  IN NO EVENT SHALL BRENT BENSON BE LIABLE TO ANY PARTY FOR DIRECT,
  INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
  OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF BRENT
  BENSON HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

  BRENT BENSON SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT
  NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
  FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER
  IS ON AN "AS IS" BASIS, AND BRENT BENSON HAS NO OBLIGATION TO
  PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
  MODIFICATIONS.
*/

#ifndef _STRING_H
#define _STRING_H

#include "scheme.h"

/*  procedure: (make-string k) or (make-string k char) 

	Make-string returns a newly allocated string of length k.
	If char is given, then all elements of the string are ini-
	tialized to char , otherwise the contents of the string are
	unspecified. But here we set them with '\0'.
*/
extern scheme_object *str_make_string(const scheme_object *obj);

/*  procedure: (string char ...)

	Returns a newly allocated string composed of the arguments.
*/
extern scheme_object *str_cons_string(const scheme_object *obj);

/*  procedure: (string-length string)

	Returns the number of characters in the given string.
*/
extern inline scheme_object *str_string_length(const scheme_object *obj);

/*  procedure: (string-ref string k)

	k must be a valid index of string. String-ref returns
	character k of string using zero-origin indexing.
*/
extern scheme_object *str_string_ref(const scheme_object *obj);


/*  procedure: (string-set! string k char )

	k must be a valid index of string. String-set! stores char
	in element k of string and returns an unspecified value.
*/
extern scheme_object *str_string_set(scheme_object *obj);

/*  procedure: (string? obj )

	Returns #t if obj is a string, otherwise returns #f.
*/
extern const inline scheme_object *str_pred_string(const scheme_object *obj);

/*  procedure: (string=? string1 string2)
	
	Returns #t if the two strings are the same length and con-
	tain the same characters in the same positions, otherwise
	returns #f.
*/
extern const scheme_object *str_pred_string_eq(const scheme_object *obj);


/* 	procedure: (string<=? string1 string2)  */
extern const scheme_object *str_pred_string_le(const scheme_object *obj);


/* 	procedure: (string<? string1 string2)  */
extern const scheme_object *str_pred_string_lt(const scheme_object *obj);


/* 	procedure: (string>=? string1 string2)  */
extern const scheme_object *str_pred_string_ge(const scheme_object *obj);

/* 	procedure: (string>? string1 string2)  */
extern const scheme_object *str_pred_string_gt(const scheme_object *obj);

/* 	procedure: (string-ci=? string1 string2)

	String-ci=? treats upper and lower case let-
	ters as though they were the same character, but string=?
	treats upper and lower case as distinct characters.
*/
extern const scheme_object *str_pred_string_ci_eq(const scheme_object *obj);

/* 	procedure: (string-ci<=? string1 string2)  */
extern const scheme_object *str_pred_string_ci_le(const scheme_object *obj);

/* 	procedure: (string-ci<? string1 string2)  */
extern const scheme_object *str_pred_string_ci_lt(const scheme_object *obj);

/* 	procedure: (string-ci>=? string1 string2)  */
extern const scheme_object *str_pred_string_ci_ge(const scheme_object *obj);

/* 	procedure: (string-ci>? string1 string2)  */
extern const scheme_object *str_pred_sring_ci_gt(const scheme_object *obj);

/* 	procedure: (substring start end)
	
	String must be a string, and start and end must be exact
	integers satisfying 0 ≤ start ≤ end ≤ (string-length string).
	Substring returns a newly allocated string formed from
	the characters of string beginning with index start (inclu-
	sive) and ending with index end (exclusive).
*/
extern scheme_object *str_substring(const scheme_object *obj);

/*  procedure: (string-append string ...)

	Returns a newly allocated string whose characters form the
	concatenation of the given strings.
*/
extern scheme_object *str_string_append(const scheme_object *obj);

/*  procedure: (string->list string)

	String->list returns a newly allocated list of the charac-
	ters that make up the given string.
*/	
extern scheme_object *str_string_to_list(const scheme_object *obj);

/* 	procedure: (list->string list)

	List->string returns a newly allocated string formed from the
	characters in the list list, which must be a list of characters.
*/	
extern scheme_object *str_list_to_string(const scheme_object *obj);

/* 	procedure: (string-copy string)

	Returns a newly allocated copy of the given string.
*/	
extern scheme_object *str_string_copy(const scheme_object *obj);

/* 	procedure: (string-fill! string char)

	Stores char in every element of the given string and returns
	an unspecified value.
*/
extern scheme_object *str_string_fill(const scheme_object *obj);

/*  This procedure is to initialize the part of string  */
extern void scheme_init_string();

#endif

