/*
  Copyright (c) 2014 Xianfei Shen
  All rights reserved.

  Permission is hereby granted, without written agreement and without
  license or royalty fees, to use, copy, modify, and distribute this
  software and its documentation for any purpose, provided that the
  above copyright notice and the following two paragraphs appear in
  all copies of this software.
 
  IN NO EVENT SHALL BRENT BENSON BE LIABLE TO ANY PARTY FOR DIRECT,
  INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
  OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF BRENT
  BENSON HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

  BRENT BENSON SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT
  NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
  FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER
  IS ON AN "AS IS" BASIS, AND BRENT BENSON HAS NO OBLIGATION TO
  PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
  MODIFICATIONS.
*/

#include "string.h"

scheme_object *str_make_string(const scheme_object *obj)
{
	if (obj == NIL) {
		error("expected: 1 to 2 arguments ==> make_string", obj);
	} else if (type(car(obj)) != TYPE_INTEGER) {
		error("expected: exact-nonnegative-integer ==> make_string", car(obj));
	} else if (fixnum(car(obj)) < 0) {
		error("expected: exact-nonnegative-integer ==> make_string", car(obj));
	} else if (cdr(obj) == NIL) {
		return create_str_obj(fixnum(car(obj)), '\0');
	} else if (type(cadr(obj)) != TYPE_CHAR) {
		error("expected: char ==> make_string", cadr(obj));
	} else if (cddr(obj) != NIL) {
		error("expected: 1 to 2 arguments ==> make_string", obj);
	} else {
		return create_str_obj(fixnum(car(obj)), Char(cadr(obj)));
	}		
}

static scheme_object *create_str_obj(unsigned int len, char c)
{
	scheme_object *str_obj = scheme_malloc(sizeof(scheme_object));
	
	type(str_obj) = TYPE_STRING;
	len(str_obj) = len;
	str(str_obj) = scheme_malloc(len + 1);
	
	for (unsigned int i = 0, char *p = str(str_obj);
	 	 i < len; ++i) {
		p[i] = c;
	}	
	p[i] = '\0';
	
	return str_obj;
}

scheme_object *str_cons_string(const scheme_object *obj)
{
	scheme_object *str_obj;
	unsigned int len = 0;
	
	for (scheme_object *p = obj; p != NIL;) {
		if (type(car(p)) != TYPE_CHAR) {
			error("expected: char ==> string", car(p));
		}
		p = cdr(p), ++len;
	}
	
	str_obj = scheme_malloc(sizeof(scheme_object));
	type(str_obj) = TYPE_STRING;
	len(str_obj) = len;
	str(str_obj) = scheme_malloc(len + 1);
	
	for (unsigned int i = 0, char *p = str(str_obj),
	     scheme_object *q = obj; i < len;) {
	     p[i] = Char(car(q));
	     q = cdr(q), ++i;
	}
	
	return str_obj;
}

inline scheme_object *str_string_length(const scheme_object *obj)
{
	if (type(car(obj)) != TYPE_STRING) {
		error("expected: string ==> string_length", obj);
	} else {
		return make_integer(len(obj));
	}
}	

scheme_object *str_string_ref(const scheme_object *obj)
{
	if (type(car(obj)) != TYPE_STRING) {
		error("expected: string ==> string_ref", obj);
	} else if (cdr(obj) == NIL) {
		error("expected: 2 arguments ==> string_ref", obj);
	} else if (type(cadr(obj)) != TYPE_INTEGER || fixnum(cadr(obj))
			   < 0 || fixnum(cadr(obj)) >= len(obj)) {
		error("expected: a valid index of string ==> string_ref", obj);
	} else if (cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string_ref", obj);
	} else {
		return (str(car(obj)))[fixnum(cadr(obj))];
	}
}

scheme_object *str_string_set(scheme_object *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj)
	    == NIL || cdddr(obj) != NIL) {
		error("expected: 3 arguments ==> string_set!", obj);
	} else if (type(car(obj)) != TYPE_STRING) {
		error("expected: string ==> string_set!", car(obj));
	} else if (type(cadr(obj)) != TYPE_INTEGER) {
		error("expected: nonnegative integer ==> string_set!", cadr(obj)); 
	} else if (fixnum(cadr(obj)) < 0 || fixnum(cadr(obj)) >= len(car(obj))) {
		error("expected: a valid index of string ==> string_set!", cadr(obj));
	} else if (type(caddr(obj)) != TYPE_CHAR) {
		error("expected: char ==> string_set!", caddr(obj));
	} else {
		(str(obj))[fixnum(cadr(obj))] = Char(caddr(obj));
	}
	
	return scheme_ok;
}

const inline scheme_object *str_pred_string(const scheme_object *obj)
{
	return type(obj) == TYPE_STRING ? scheme_true : scheme_false;
} 

const scheme_object *str_pred_string_eq(const scheme_object *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string=?", obj);
	} else if (type(car(obj)) != TYPE_STRING || type(cadr(obj)) != TYPE_STRING) {
		error("expected: string ==> string=?", obj);
	} else {
		return strcmp(str(car(obj)), str(cadr(obj))) == 0 ? scheme_true : scheme_false;
	}
}

const scheme_object *str_pred_string_le(const scheme_object *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string<=?", obj);
	} else if (type(car(obj)) != TYPE_STRING || type(cadr(obj)) != TYPE_STRING) {
		error("expected: string ==> string<=?", obj);
	} else {
		return strcmp(str(car(obj)), str(cadr(obj))) <= 0 ? scheme_true : scheme_false;
	}
}

const scheme_object *str_pred_string_lt(const scheme_object *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string<?", obj);
	} else if (type(car(obj)) != TYPE_STRING || type(cadr(obj)) != TYPE_STRING) {
		error("expected: string ==> string<?", obj);
	} else {
		return strcmp(str(car(obj)), str(cadr(obj))) < 0 ? scheme_true : scheme_false;
	}
}

const scheme_object *str_pred_string_ge(const scheme_object *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string>=?", obj);
	} else if (type(car(obj)) != TYPE_STRING || type(cadr(obj)) != TYPE_STRING) {
		error("expected: string ==> string>=?", obj);
	} else {
		return strcmp(str(car(obj)), str(cadr(obj))) >= 0 ? scheme_true : scheme_false;
	}
}

const scheme_object *str_pred_string_gt(const scheme_object *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string>?", obj);
	} else if (type(car(obj)) != TYPE_STRING || type(cadr(obj)) != TYPE_STRING) {
		error("expected: string ==> string>?", obj);
	} else {
		return strcmp(str(car(obj)), str(cadr(obj))) > 0 ? scheme_true : scheme_false;
	}
}

static scheme_object *upper_to_lower(scheme_object *obj)
{
	for (char *p = str(obj); p != '\0'; ++p) {
		if (*p >= 'A' && *p <= 'Z') {
			*p += ('a' - 'A');
		}
	}
	
	return obj;
}

static scheme_object *lower_to_upper(scheme_object *obj)
{
	for (char *p = str(obj); p != '\0'; ++p) {
		if (*p >= 'a' && *p <= 'z') {
			*p -= ('a' - 'A');
		}
	}
		
	return obj;
}

const scheme_object *str_pred_string_ci_eq(const scheme_object *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string-ci=?", obj);
	} else if (type(car(obj)) != TYPE_STRING || type(cadr(obj)) != TYPE_STRING) {
		error("expected: string ==> string-ci=?", obj);
	} else {
		scheme_object *p = upper_to_lower(car(obj));
		scheme_object *q = upper_to_lower(cadr(obj));
		return strcmp(str(p), str(q)) == 0 ? scheme_true : scheme_false;
	}
}

const scheme_object *str_pred_string_ci_le(const scheme_object *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string-ci<=?", obj);
	} else if (type(car(obj)) != TYPE_STRING || type(cadr(obj)) != TYPE_STRING) {
		error("expected: string ==> string-ci<=?", obj);
	} else {
		scheme_object *p = upper_to_lower(car(obj));
		scheme_object *q = upper_to_lower(cadr(obj));
		return strcmp(str(p), str(q)) <= 0 ? scheme_true : scheme_false;
	}
}	

const scheme_object *str_pred_string_ci_lt(const scheme_object *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string-ci<?", obj);
	} else if (type(car(obj)) != TYPE_STRING || type(cadr(obj)) != TYPE_STRING) {
		error("expected: string ==> string-ci<?", obj);
	} else {
		scheme_object *p = upper_to_lower(car(obj));
		scheme_object *q = upper_to_lower(cadr(obj));
		return strcmp(str(p), str(q)) < 0 ? scheme_true : scheme_false;
	}
}

const scheme_object *str_pred_string_ci_ge(const scheme_object *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string-ci>=?", obj);
	} else if (type(car(obj)) != TYPE_STRING || type(cadr(obj)) != TYPE_STRING) {
		error("expected: string ==> string-ci>=?", obj);
	} else {
		scheme_object *p = upper_to_lower(car(obj));
		scheme_object *q = upper_to_lower(cadr(obj));
		return strcmp(str(p), str(q)) >= 0 ? scheme_true : scheme_false;
	}
}

const scheme_object *str_pred_string_ci_gt(const scheme_object *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string-ci>?", obj);
	} else if (type(car(obj)) != TYPE_STRING || type(cadr(obj)) != TYPE_STRING) {
		error("expected: string ==> string-ci>?", obj);
	} else {
		scheme_object *p = upper_to_lower(car(obj));
		scheme_object *q = upper_to_lower(cadr(obj));
		return strcmp(str(p), str(q)) > 0 ? scheme_true : scheme_false;
	}
}

static scheme_object *make_string(const char *str)
{
	unsigned int len = strlen(str);
	scheme_object *str_obj;
	
	str_obj = scheme_malloc(sizeof(scheme_object));
    type(str_obj) = TYPE_STRING;
	len(str_obj) = len;
	str(str_obj) = scheme_malloc(len + 1);
	strcpy(str(str_obj), str);
	
	return str_obj;
}

scheme_object *str_substring(const scheme_object *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj)
		== NIL || cdddr(obj) != NIL) {
		error("expected: 3 arguments ==> substring", obj);
	} else if (type(car(obj)) != TYPE_STRING) {
		error("expected: string ==> substring", car(obj));
	} else if (type(cadr(obj)) != TYPE_INTEGER ||
			   type(caddr(obj)) != TYPE_INTEGER ||
			   fixnum(cadr(obj)) < 0 || fixnum(cadr(obj)) >= len(car(obj)) ||
			   fixnum(caddr(obj)) < 0 || fixnum(caddr(obj)) >= len(car(obj))) {
		error("expected: a valid index of string ==> substring", obj);
	} else {
		unsigned int len = fixnum(caddr(obj)) - fixnum(cadr(obj));
		if (len < 0) {
			error("expected: ending index is smaller than starting"
			      "index ==> substring", obj);
		}			
		scheme_object *str_obj = scheme_malloc(sizeof(scheme_object));
		type(str_obj) = TYPE_STRING;
		len(str_obj) = len;
		str(str_obj) = scheme_malloc(len + 1);
		strncpy(str(str_obj), str(obj) + fixnum(cadr(obj)), len);
		
		return str_obj;
	}
}

scheme_object *str_string_append(const scheme_object *obj)
{
}

scheme_object *str_string_to_list(const scheme_object *obj)
{
	if (obj == NIL || cdr(obj) != NIL) {
		error("expected: 1 argument ==> string->list", obj);
	} else if (type(car(obj)) != TYPE_STRING) {
		error("expected: string ==> string->list", car(obj));
	} else {
		unsigned int len = len(car(obj));
	}
}

scheme_object *str_list_ot_string(const scheme_object *obj)
{
	if (obj == NIL || cdr(obj) != NIL) {
		error("expected: 1 argument ==> list->string", obj);
	} else {
		scheme_object *p = car(obj);
		unsigned int len = 
	}
}

scheme_object *str_string_copy(const scheme_object *obj)
{
	if (obj == NIL || cdr(obj) != NIL) {
		error("expected: 1 argument ==> string-copy", obj);
	} else if (type(car(obj)) != TYPE_STRING) {
		error("expected: string ==> string-copy", car(obj));
	} else {
		unsigned int len = len(car(obj));
		scheme_object *str_obj = scheme_malloc(sizeof(scheme_object));
		type(str_obj) = TYPE_STRING;
		len(str_obj) = len;
		str(str_obj) = scheme_malloc(len + 1);
		strcpy(str(str_obj), str(obj));
				
		return str_obj;
	}
}
		
scheme_object *str_string_fill(const scheme_object *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 argument ==> string-fill!", obj);
	} else if (type(car(obj)) != TYPE_STRING) {
		error("expected: string ==> string-fill!", car(obj));
	} else if (type(cadr(obj)) != TYPE_CHAR) {
		error("expected: char ==> string-fill!", cadr(obj));
	} else {
		char *p = str(car(obj)), c = Char(cadr(obj));
		for (unsigned int i = 0, len = len(car(obj)); 
			 i < len; i++) {
			 p[i] = c;
		}
		
		return scheme_ok;
	}
}

void scheme_init_string()
{
	scheme_add_prim("string?", str_pred_string);
	scheme_add_prim("make-string", str_make_string);
	scheme_add_prim("string", str_cons_string);
	scheme_add_prim("string-length", str_string_length);
	scheme_add_prim("string-ref", str_string_ref);
	scheme_add_prim("string-set!", str_string_set);
	scheme_add_prim("string=?", str_pred_string_eq);	
	scheme_add_prim("string<?", str_pred_string_lt);
	scheme_add_prim("string>?", str_pred_string_gt);
	scheme_add_prim("string<=?", str_pred_string_le);
	scheme_add_prim("string>=?", str_pred_string_ge);
	scheme_add_prim("string-ci=?", str_pred_string_ci_eq);
	scheme_add_prim("string-ci<?", str_pred_string_ci_lt);
	scheme_add_prim("string-ci>?", str_pred_string_ci_gt);
	scheme_add_prim("string-ci<=?", str_pred_string_ci_le);
	scheme_add_prim("string-ci>=?", str_pred_string_ci_ge);
	scheme_add_prim("substring", str_substring);
	scheme_add_prim("string-append", str_string_append);
	scheme_add_prim("string->list", str_string_to_list);
	scheme_add_prim("list->string", str_list_to_string);
	scheme_add_prim("string-copy", str_string_copy);
	scheme_add_prim("string-fill!", str_string_fill);
}

			








																		 
		
