/*
  Copyright (c) 2014 Xianfei Shen
  All rights reserved.

  Permission is hereby granted, without written agreement and without
  license or royalty fees, to use, copy, modify, and distribute this
  software and its documentation for any purpose, provided that the
  above copyright notice and the following two paragraphs appear in
  all copies of this software.
 
  IN NO EVENT SHALL BRENT BENSON BE LIABLE TO ANY PARTY FOR DIRECT,
  INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
  OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF BRENT
  BENSON HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

  BRENT BENSON SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT
  NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
  FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER
  IS ON AN "AS IS" BASIS, AND BRENT BENSON HAS NO OBLIGATION TO
  PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
  MODIFICATIONS.
*/

#ifndef _scheme_object_H
#define _scheme_object_H

typedef unsigned int TYPE;

struct scheme_object {
	TYPE type;
	union {
		struct { char c; } Char;
		struct { double real; double image; } complex;
		struct { long long num; } fixnum;
		struct { 
			struct scheme_object *car; 
			struct scheme_object *cdr
		} pair;
		struct { unsigned int index; } prim;
		struct { long numer; long denom; } rational;
		struct { double flonum; } real;
		struct { unsigned int len; char *str; } string;
		struct {
			unsigned int len; 
			struct scheme_object **vec;
	    } vector;		
	} value;
}

typedef struct scheme_object scheme_object;

enum { T_BOOLEAN, T_CONT, T_EMPTY, T_KEYWORD,
	   T_MACRO, T_FIXNUM, T_PAIR, T_PRIM, 
	   T_QUOTE, T_QQUOTE, T_REAL, T_STRING,
	   T_SYMBOL, T_UNQUOTE, T_UQSPLIC, T_VECTOR };

#define     car(p)      ((p)->value.pair.car)
#define     cdr(p)      ((p)->value.pair.cdr)
#define		fixnum(p)   ((p)->value.fixnum.num)
#define     real(p)     ((p)->value.real.flonum)
#define     str(p)      ((p)->value.string.str)
#define     type(p)     ((p)->TYPE)


#define 	is_cont(p)    	(type(p) == T_CONT)
#define 	is_fixnum(p)  	(type(p) == T_FIXNUM)
#define 	is_keyword(p) 	(type(p) == T_KEYWORD)
#define 	is_macro(p)   	(type(p) == T_MACRO)
#define 	is_null(p)    	(type(p) == T_EMPTY)
#define 	is_pair(p)    	(type(p) == T_PAIR)
#define 	is_prim(p)    	(type(p) == T_PRIM)
#define 	is_quoted(p)  	(type(p) == T_QUOTE)
#define 	is_real(p)    	(type(p) == T_REAL)
#define 	is_string(p)  	(type(p) == T_STRING)
#define 	is_symbol(p)  	(type(p) == T_SYMBOL)
#define 	is_vector(p)  	(type(p) == T_VECTOR)

#define 	caar(p)    	(car(car(p)))
#define 	cadr(p)    	(car(cdr(p)))
#define 	cdar(p)    	(cdr(car(p)))
#define 	cddr(p)    	(cdr(cdr(p)))
#define 	caddr(p)   	(car(cddr(p)))
#define 	cdadr(p)   	(cdr(cadr(p)))
#define		cdddr(p)   	(cdr(cddr(p)))
#define 	cadddr(p)  	(car(cdddr(p)))

#endif
		
	


