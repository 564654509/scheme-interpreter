/*
  Copyright (c) 2014 Xianfei Shen
  All rights reserved.

  Permission is hereby granted, without written agreement and without
  license or royalty fees, to use, copy, modify, and distribute this
  software and its documentation for any purpose, provided that the
  above copyright notice and the following two paragraphs appear in
  all copies of this software.
 
  IN NO EVENT SHALL BRENT BENSON BE LIABLE TO ANY PARTY FOR DIRECT,
  INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
  OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF BRENT
  BENSON HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

  BRENT BENSON SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT
  NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
  FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER
  IS ON AN "AS IS" BASIS, AND BRENT BENSON HAS NO OBLIGATION TO
  PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
  MODIFICATIONS.
*/


#include "scm.h"

static void eval(const scheme_object *exp, scheme_object *env)
{
	const scheme_object *p;
	const scheme_object *q;
	
repeat:
	if (is_const(exp)) {
		return exp;
	} else if (is_symbol(exp)) {
		for(p = env; p != NIL; p = cdr(p)) {
			for(q = car(p); q != NIL; q = cdr(q)) {
				if(caar(q) == exp) {
					return cdar(q);
				}
			}
		}
		error("unbounded bariable", exp);
	} else {
		Type t = type(car(exp));
		if (is_pair(t)) {
			switch (t) {
			case T_QUOTE:
				return cadr(exp);
				break;
			case T_IF:
				p = eval(cadr(exp), env);
				if(is_true(p)) {
					exp = caddr(exp);
				} else {
					if(!is_null(cdddr(exp))) {
						exp = cadddr(exp);
					}
				}
				break;
			case T_LAMBDA:
				p = cons(cadr(exp), cons(cddr(exp), cons(env, NIL)));
			 	type(p) = T_CLOSURE;
			 	return p;
			 	break;
			case T_BEGIN:
				while(!is_null(cdr(exp))) {
					eval(car(exp), env);
					exp = cdr(exp);
				}
				exp = car(exp);
				break;
			case T_SET:
				assign(env, cadr(exp), eval(caddr(exp), env));
				return ;
				break;
			case T_DEFINE:
				if(is_symbol(cadr(exp))) {
					add-binding(env, cadr(exp), eval(caddr(exp), env));
				} else {
					add-binding(env, caadr(exp), eval(cons(LAMBDA,
						 cons(cdadr(exp), cddr(exp))), env));
				}
				return ;
				break;
			case T_DEFMAC:
				p = cons(caddr(exp), cdddr(exp));
				type(p) = T_MACRO;
				add-binding(env, cadr(exp), p);
				return ;
				break;
			default:
				break;
			}
		} else {
			error("unknow expression type", exp);
		}
	}
	goto repeat;
}

inline static scheme_object *lookup(
		const scheme_object *exp, 
		const scheme_object *env)
{
}

inline static scheme_object *add-binding( 
		const scheme_object *env, 
		const scheme_object *var,
		const scheme_object *val)
{
}
		

			
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
			
		
