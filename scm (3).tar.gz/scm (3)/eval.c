/*
  Copyright (c) 2014 Xianfei Shen
  All rights reserved.

  Permission is hereby granted, without written agreement and without
  license or royalty fees, to use, copy, modify, and distribute this
  software and its documentation for any purpose, provided that the
  above copyright notice and the following two paragraphs appear in
  all copies of this software.
 
  IN NO EVENT SHALL BRENT BENSON BE LIABLE TO ANY PARTY FOR DIRECT,
  INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
  OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF BRENT
  BENSON HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

  BRENT BENSON SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT
  NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
  FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER
  IS ON AN "AS IS" BASIS, AND BRENT BENSON HAS NO OBLIGATION TO
  PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
  MODIFICATIONS.
*/


#include "header.h"

#define  apply(prim, args)  (*(proc(prim)))(args)
		
static scm_obj *eval(register const scm_obj *exp, register scm_obj *env)
{
	scm_obj *proc;
	scm_type type;
	
repeat:
	scm_type type = type(exp);
	
	if (type == CONST) {
		return exp;
	} else if (type == SYMBOL) {
		scm_obj *val = lookup(exp, env);
		
		if (val == scm_null) {
			error("unbounded bariable", exp);
		} else {
			return cdr(val);
		}
	} else if (type == PAIR) {
		scm_obj *first = car(exp);
		
		if (first == scm_quote) {
			return cadr(exp);
		} else if (first == scm_if) {
			if (eval(cadr(exp), env) == scm_true) {
				exp = caddr(exp);
			} else if (cdddr(exp) != scm_null) {
				exp = cadddr(exp);
			} else {
				return scm_unspecified;
			}
			goto repeat;
		} else if (first == scm_lambda) {
			proc = cons(cadr(exp), cons(cddr(exp), env));
			return cons(scm_closure, cons(proc, scm_null));
		} else if (first == scm_begin) {
			while (cdr(exp) != scm_null) {
				eval(car(exp), env);
				exp = cdr(exp);
			}
			exp = car(exp);
			goto repeat;
		} else if (first == scm_define) {
			scm_obj *val;
			
			if (type(cadr(exp)) == SYMBOL) {
				val = eval(caddr(exp), env);
				return add-binding(cadr(exp), val, env);
			} else {
				val = eval(cons(scm_lambda, cons(cdadr(exp), cddr(exp))), env);
				return add-binding(caadr(exp), val, env);
			}
		} else if (first == scm_defmac) {
			scm_obj *val = cons(cons(scm_macro, cons(caddr(exp), cdddr(exp))), scm_null);
			return add-binding(cadr(exp), val, env);
		} else {
			proc = eval(first, env);
			
			if (type(proc) == PAIR && car(proc) == scm_macro) {
				scm_obj *body = eval(cons(scm_begin, caddr(proc)), 
							         extend(cadr(proc), cdr(exp), env));
							
				if (type(pair) == PAIR) {
					exp = body;
				} else {
					exp = cons(cons(scm_begin, body), scm_null);
				}
				goto repeat;
			} else {
				scm_obj *args = eval(cons(scm_begin, cdr(exp)), env);
				
				if (type(proc) == PAIR) {
					exp = cons(scm_begin, caddr(proc));
					env = extend(cadr(proc), args, cadddr(proc));
					goto repeat;
				} else {
					return apply(proc, args);
				}
			}
		}
	} else {
		error("unknow expression type", exp);
	}					
}


		

			
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
			
		
