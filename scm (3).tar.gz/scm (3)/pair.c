/*
  Copyright (c) 2014 Xianfei Shen
  All rights reserved.

  Permission is hereby granted, without written agreement and without
  license or royalty fees, to use, copy, modify, and distribute this
  software and its documentation for any purpose, provided that the
  above copyright notice and the following two paragraphs appear in
  all copies of this software.
 
  IN NO EVENT SHALL BRENT BENSON BE LIABLE TO ANY PARTY FOR DIRECT,
  INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
  OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF BRENT
  BENSON HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

  BRENT BENSON SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT
  NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
  FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER
  IS ON AN "AS IS" BASIS, AND BRENT BENSON HAS NO OBLIGATION TO
  PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
  MODIFICATIONS.
*/

#include "header.h"

inline const scm_obj *pair_pred_pair(const scm_obj *obj)
{
	if (obj == scm_null || cdr(obj) != scm_null) {
		error("expected: 1 argument ==> pair?", obj);
	} else {
		return type(car(obj)) == PAIR ? scm_true : scm_false;
	}
}

inline scm_obj *pair_cons(const scm_obj *obj)
{
	if (obj == scm_null || cdr(obj) == scm_null || cddr(obj) != scm_null) {
		error("expected: 2 arguments ==> cons", obj);
	} else {
		return cons(car(obj), cadr(obj));
	}
}

scm_obj *pair_car(const scm_obj *obj)
{
	if (obj == scm_null || cdr(obj) != scm_null) {
		error("expected: 1 argument ==> car", obj);
	} else if (type(car(obj)) != PAIR) {
		error("expected: pair ==> car", car(obj));
	} else {
		return caar(obj);
	}
}

scm_obj *pair_cdr(const scm_obj *obj)
{
	if (obj == scm_null || cdr(obj) != scm_null) {
		error("expected: 1 argument ==> cdr", obj);
	} else if (type(car(obj)) != PAIR) {
		error("expected: pair ==> cdr", car(obj));
	} else {
		return cdar(obj);
	}
}

scm_obj *pair_set_car(const scm_obj *obj)
{
	if (obj == scm_null || cdr(obj) == scm_null || cddr(obj) != scm_null) {
		error("expected: 2 arguments ==> set-car!", obj);
	} else if (type(car(obj)) != PAIR) {
		error("expected: 1 argument ==> set-car!", car(obj));
	} else {
		caar(obj) = cadr(obj);
		return scm_unspecified;
	}
}

scm_obj *pair_set_cdr(const scm_obj *obj)
{
	if (obj == scm_null || cdr(obj) == scm_null || cddr(obj) != scm_null) {
		error("expected: 2 arguments ==> set-cdr!", obj);
	} else if (type(car(obj)) != PAIR) {
		error("expected: 1 argument ==> set-cdr!", car(obj));
	} else {
		cdar(obj) = cadr(obj);
		return scm_unspecified;
	}
}

void scm_init_pair()
{
	scm_add_prim("pair?", pair_pred_pair);
	scm_add_prim("cons", pair_cons);
	scm_add_prim("car", pair_car);
	scm_add_prim("cdr", pair_cdr);
	scm_add_prim("set-car!", pair_set_car);
	scm_add_prim("set-cdr!", pair_set_cdr);
}
		
		
		
		
		
		
		
		
		
		
	
