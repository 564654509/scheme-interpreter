/*
  Copyright (c) 2014 Xianfei Shen
  All rights reserved.

  Permission is hereby granted, without written agreement and without
  license or royalty fees, to use, copy, modify, and distribute this
  software and its documentation for any purpose, provided that the
  above copyright notice and the following two paragraphs appear in
  all copies of this software.
 
  IN NO EVENT SHALL BRENT BENSON BE LIABLE TO ANY PARTY FOR DIRECT,
  INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
  OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF BRENT
  BENSON HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

  BRENT BENSON SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT
  NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
  FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER
  IS ON AN "AS IS" BASIS, AND BRENT BENSON HAS NO OBLIGATION TO
  PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
  MODIFICATIONS.
*/

#include "header.h"

scm_obj *num_add(const scm_obj *obj)
{
	long res = 0;
	
	while (obj != scm_null) {
		if (type(car(obj)) != INTEGER) {
			error("expected: integer ==> add", car(obj));
		} else {
			res += fixnum(car(obj));
			obj = cdr(obj);
		}
	}
	
	return make_integer(res);
}
		
scm_obj *num_sub(const scm_obj *obj)
{
	long res = 0;
	
	if (obj == NIL) {
		error("expected: at least 1 argument ==> sub", obj);
	} else if (type(car(obj)) != INTEGER) {
		error("expected: integer ==> sub", car(obj));
	} else {
		res = fixnum(car(obj));
		obj = cdr(obj);
	}
	
	while (obj != scm_null) {
		if (type(car(obj)) != INTEGER) {
			error("expected: integer ==> sub", car(obj));
		} else {
			res -= fixnum(car(obj));
			obj = cdr(obj);
		}
	}
	
	return make_integer(res);
}

scm_obj *num_mul(const scm_obj *obj)
{
	long res = 1;
	
	while (obj != scm_null) {
		if (type(car(obj)) != INTEGER) {
			error("expected: integer ==> mul", car(obj));
		} else {
			res *= fixnum(car(obj));
			obj = cdr(obj);
		}
	}
	
	return make_integer(res);
}

scm_obj *num_div(const scm_obj *obj)
{
	long res = 0;
	
	if (obj == NIL) {
		error("expected: at least 1 argument ==> div", obj);
	} else if (type(car(obj)) != INTEGER) {
		error("expected: integer ==> div", car(obj));
	} else {
		res = fixnum(car(obj));
		obj = cdr(obj);
	}
	
	while (obj != scm_null) {
		if (type(car(obj)) != INTEGER) {
			error("expected: integer ==> div", car(obj));
		} else if (fixnum(car(obj)) == 0) {
			error("division by zero ==> div", car(obj));
		} else {
			res -= fixnum(car(obj));
			obj = cdr(obj);
		}
	}
	
	return make_integer(res);
}

scm_obj *num_mod(const scm_obj *obj)
{
	if (obj == scm_null || cdr(obj) == scm_null || cddr(obj) != scm_null) {
		error("expected: 2 arguments ==> mod", obj);
	} else if (type(car(obj)) != INTEGER) {
		error("expected: integer ==> mod", car(obj));
	} else if (type(cadr(obj)) != INTEGER) {
		error("expected: integer ==> mod", cadr(obj));
	} else {
		long res = fixnum(car(obj)) % fixnum(cadr(obj));		
		return make_integer(res);
	}
}

void scm_init_number()
{
	scm_add_prim("+", num_add);
	scm_add_prim("-", num_sub);
	scm_add_prim("*", num_mul);
	scm_add_prim("/", num_div);
	scm_add_prim("mod", num_mod);
}
	
