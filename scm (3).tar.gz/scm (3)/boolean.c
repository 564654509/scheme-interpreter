/*
  Copyright (c) 2014 Xianfei Shen
  All rights reserved.

  Permission is hereby granted, without written agreement and without
  license or royalty fees, to use, copy, modify, and distribute this
  software and its documentation for any purpose, provided that the
  above copyright notice and the following two paragraphs appear in
  all copies of this software.
 
  IN NO EVENT SHALL BRENT BENSON BE LIABLE TO ANY PARTY FOR DIRECT,
  INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
  OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF BRENT
  BENSON HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

  BRENT BENSON SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT
  NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
  FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER
  IS ON AN "AS IS" BASIS, AND BRENT BENSON HAS NO OBLIGATION TO
  PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
  MODIFICATIONS.
*/

#include "boolean.h"

scm_obj *bool_pred_eq(const scm_obj *obj);
	
scm_obj *bool_pred_eqv(const scm_obj *obj)
{
	const scm_obj *obj1, *obj2;
	
	if (obj == scm_null || cdr(obj) == scm_null || cddr(obj) != scm_null) {
		error("expected: 2 arguments ==> eqv?", obj);
	}
	obj1 = car(obj);
	obj2 = cadr(obj);
	
	if (obj1 == obj2) {
		return scm_true;
	} else if (type(obj1) == SYMBOL && type(obj2) == SYMBOL) {
		;
	} else if (type(obj1) != type(obj2)) {
		return scm_false;
	}
}

void scm_init_boolean()
{
}

