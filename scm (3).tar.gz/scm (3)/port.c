/*
  Copyright (c) 2014 Xianfei Shen
  All rights reserved.

  Permission is hereby granted, without written agreement and without
  license or royalty fees, to use, copy, modify, and distribute this
  software and its documentation for any purpose, provided that the
  above copyright notice and the following two paragraphs appear in
  all copies of this software.
 
  IN NO EVENT SHALL BRENT BENSON BE LIABLE TO ANY PARTY FOR DIRECT,
  INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
  OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF BRENT
  BENSON HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

  BRENT BENSON SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT
  NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
  FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER
  IS ON AN "AS IS" BASIS, AND BRENT BENSON HAS NO OBLIGATION TO
  PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
  MODIFICATIONS.
*/

#include "header.h"

scm_obj *scm_cur_input_port;
scm_obj *scm_cur_output_port;

scm_obj *port_call_with_input_file(const scm_obj *obj)
{
	if (obj == scm_null || cdr(obj) == scm_null || cddr(obj) != scm_null) {
		error("expected: 2 argument ==> call-with-input-file", obj);
	} else if (type(car(obj)) != STRING) {
		error("expected: string ==> call-with-input-file", car(obj));
	} else if (type(cadr(obj)) != PRIM || type(cadr(obj)) != PROC) {
		error("expected: proc ==> call-with-input-file", cadr(obj));
	} else {
		char *name = str(car(obj));
		FILE *fp = fopen(name, "r");
		scm_obj *port_obj, *ret;
		
		if (fp == NULL) {
			error("can't open input file ==> call-with-input-file", car(obj));
		}
		
		port_obj = scm_alloc_obj();
		type(port_obj) = INPORT;
		port(port_obj) = fp;
		ret = eval(cons(cadr(obj), cons(port_obj, scm_null)), init_env);
		
		fclose(fp);
		return ret;
	}
}

scm_obj *port_call_with_output_file(const scm_obj *obj)
{
	if (obj == scm_null || cdr(obj) == scm_null || cddr(obj) != scm_null) {
		error("expected: 2 arguments ==> call-with-output-file", obj);
	} else if (type(car(obj)) != STRING) {
		error("expected: string ==> call-with-output-file", car(obj));
	} else if (type(cadr(obj)) != PRIM || type(cadr(obj)) != PROC) {
		error("expected: proc ==> call-with-output-file", cadr(obj));
	} else {
		char *name = str(car(obj));
		FILE *fp = fopen(name, "w");
		scm_obj *port_obj, *ret;
		
		if (fp == NULL) {
			error("can't open output file ==> call-with-output-file", car(obj));
		}
		
		port_obj = scm_alloc_obj();
		type(port_obj) = OUTPORT;
		port(port_obj) = fp;
		ret = eval(cons(cadr(obj), cons(port_obj, scm_null)), init_env);
		
		fclose(fp);
		return ret;
	}
}
		
inline const scm_obj *port_pred_input_port(const scm_obj *obj)
{
	if (obj == scm_null || cdr(obj) != scm_null) {
		error("expected: 1 argument ==> input-port?", obj);
	} else {
		return type(car(obj)) == INPORT ? scm_true : scm_false;
	}
}

inline const scm_obj *port_pred_output_port(const scm_obj *obj)
{
	if (obj == scm_null || cdr(obj) != scm_null) {
		error("expected: 1 argument ==> output-port?", obj);
	} else {
		return type(car(obj)) == OUTPORT ? scm_true : scm_false;
	}
}

inline const scm_obj *port_current_input_port(const scm_obj *obj)
{
	if (obj != scm_null) {
		error("expected: 0 argument ==> current-input-port", obj);
	} else {
		return scm_cur_input_port;
	}
}

inline const scm_obj *port_current_output_port(const scm_obj *obj)
{
	if (obj != scm_null) {
		error("expected: 0 argument ==> current-output-port", obj);
	} else {
		return scm_cur_output_port;
	}
}

scm_obj *port_open_input_file(const scm_obj *obj)
{
	if (obj == scm_null || cdr(obj) != scm_null) {
		error("expected: 1 argument ==> open-input-file", obj);
	} else if (type(car(obj)) != STRING) {
		error("expected: string ==> open-input-file", car(obj));
	} else {
		scm_obj *port_obj;
		char *name = str(car(obj));
		FILE *fp = fopen(name, "r");
		
		if (fp == NULL) {
			error("can't open input file ==> open-input-file", car(obj));
		} else {
			port_obj = scm_alloc_obj();
			type(port_obj) = INPORT;
			port(port_obj) = fp;
			
			return port_obj;
		}
	}
}

scm_obj *port_open_output_file(const scm_obj *obj)
{
	if (obj == scm_null || cdr(obj) != scm_null) {
		error("expected: 1 argument ==> open-output-file", obj);
	} else if (type(car(obj)) != STRING) {
		error("expected: string ==> open-output-file", car(obj));
	} else {
		scm_obj *port_obj;
		char *name = str(car(obj));
		FILE *fp = fopen(name, "w");
		
		if (fp == NULL) {
			error("can't open output file ==> open-output-file", car(obj));
		} else {
			port_obj = scm_alloc_obj();
			type(port_obj) = OUTPORT;
			port(port_obj) = fp;
			
			return port_obj;
		}
	}
}

scm_obj *port_close_input_port(const scm_obj *obj)
{
	if (obj == scm_null || cdr(obj) != scm_null) {
		error("expected: 1 argument ==> close_input_port", obj);
	} else if (type(car(obj)) != INPORT) {
		error("expected: INPORT ==> close_input_port", car(obj));
	} else {
		FILE *fp = port(obj);
		
		fclose(fp);
		return scm_unsepcified;
	}
}
	
scm_obj *port_close_output_port(const scm_obj *obj)
{
	if (obj == scm_null || cdr(obj) != scm_null) {
		error("expected: 1 argument ==> close_output_port", obj);
	} else if (type(car(obj)) != OUTPORT) {
		error("expected: OUTPORT ==> close_output_port", car(obj));
	} else {
		FILE *fp = port(obj);
		
		fclose(fp);
		return scm_unsepcified;
	}
}	
	
void scm_init_port()
{
	scm_cur_input_port = make_port(stdin, INPORT);
	scm_cur_output_port = make_port(stdout, OUTPORT);
	
	scm_add_prim("call_with_input_file", port_call_with_input_file);
	scm_add_prim("call_with_output_file", port_call_with_output_file);
	scm_add_prim("input-port?", port_pred_input_port);
	scm_add_prim("output-port?", port_pred_output_port);
	scm_add_prim("current_input_port", port_current_input_port);
	scm_add_prim("current_output_port", port_current_output_port);
	scm_add_prim("open_input_file", port_open_input_file);
	scm_add_prim("open_output_file", port_open_output_file);
	scm_add_prim("close_input_port", port_close_input_port);
	scm_add_prim("close_output_port", port_close_output_port);
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
