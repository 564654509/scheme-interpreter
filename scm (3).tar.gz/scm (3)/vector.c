/*
  Copyright (c) 2014 Xianfei Shen
  All rights reserved.

  Permission is hereby granted, without written agreement and without
  license or royalty fees, to use, copy, modify, and distribute this
  software and its documentation for any purpose, provided that the
  above copyright notice and the following two paragraphs appear in
  all copies of this software.
 
  IN NO EVENT SHALL BRENT BENSON BE LIABLE TO ANY PARTY FOR DIRECT,
  INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
  OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF BRENT
  BENSON HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

  BRENT BENSON SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT
  NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
  FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER
  IS ON AN "AS IS" BASIS, AND BRENT BENSON HAS NO OBLIGATION TO
  PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
  MODIFICATIONS.
*/

#include "header.h"

scm_obj *vec_make_vector(const scm_obj *obj)
{
	if (obj == scm_null || cddr(obj) != scm_null) {
		error("expected: 1 or 2 arguments ==> make-vector", obj);
	} else if (type(car(obj)) != INTEGER || fixnum(car(obj)) < 0) {
		error("expected: a nonnegative integer ==> make-vector", car(obj));
	} else {
		scm_obj *elt, *vec_obj;
		
		if (cdr(obj) != scm_null) {
			elt = cadr(obj);
		} else {
			elt = scm_make_integer(0);
		}
		
		vec_obj = scm_alloc_obj();
		type(vec_obj) = VECTOR;
		vlen(vec_obj) = fixnum(car(obj));
		vec(vec_obj) = scm_alloc_vec(vlen(vec_obj));
		
		for (unsigned i = 0; i < vlen(vec_obj); i++) {
			(vec(vec_obj))[i] = scm_alloc_obj();
			*((vec(vec_obj))[i]) = *elt;
		}
		
		return vec_obj;
	}
} 

inline scm_obj *vec_vector_length(const scm_obj *obj)
{
	if (obj == scm_null || cdr(obj) != scm_null) {
		error("expected: 1 argument ==> vector-length", obj);
	} else if (type(car(obj)) != VECTOR) {
		error("expected: vector ==> vector-length", car(obj));
	} else {
		return vlen(car(obj));
	}
}

scm_obj *vec_vector_ref(const scm_obj *obj)
{
	if (obj == scm_null || cdr(obj) == scm_null || cddr(obj) != scm_null) {
		error("expected: 2 arguments ==> vector-ref", obj);
	} else if (type(car(obj)) != VECTOR) {
		error("expected: vector ==> vector-ref", car(obj));
	} else if (type(cadr(obj)) != INTEGER || fixnum(cadr(obj)) < 0 ||
			                     fixnum(cadr(obj)) >= vlen(car(obj))) {	
		error("expecte: a valid index of vector ==> vector-ref", cadr(obj));
	} else {
		return (vec(car(obj)))[fixnum(cadr(obj))];
	}
}

scm_obj *vec_vector_set(const scm_obj *obj)
{
	if (obj == scm_null || cdr(obj) == scm_null ||
		cddr(obj) == scm_null || cdddr(obj) != scm_null) {
		error("expected: 3 arguments ==> vector-set!", obj);
	} else if (type(car(obj)) != VECTOR) {
		error("expected: vector ==> vector-set!", car(obj));
	} else if (type(cadr(obj)) != INTEGER || fixnum(cadr(obj)) < 0 ||
			                     fixnum(cadr(obj)) >= vlen(car(obj))) {	
		error("expecte: a valid index of vector ==> vector-set!", cadr(obj));
	} else {
		(vec(car(obj)))[fixnum(cadr(obj))] = caddr(obj);
		return scm_ok;
	}
}

inline const scm_obj *vec_pred_vector(const scm_obj *obj)
{
	if (obj == scm_null || cdr(obj) != scm_null) {
		error("expected: 1 argument ==> vector?", obj);
	} else {
		return type(car(obj)) == VECTOR ? scm_true : scm_false;
	}
}

void scm_init_vector()
{
	scm_add_prim("make-vector", vec_make_vector);
	scm_add_prim("vector", vec_cons_vector);
	scm_add_prim("vector-length", vec_vector_length);
	scm_add_prim("vector-ref", vec_vector_ref);
	scm_add_prim("vector-set", vec_vector_set);
	scm_add_prim("vector?", vec_pred_vector);
}
			
	
	
	
	
	
	
	
	
