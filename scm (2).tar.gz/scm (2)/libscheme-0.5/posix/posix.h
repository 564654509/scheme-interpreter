/*
   posix.h
*/

#ifndef POSIX_H
#define POSIX_H

#include <scheme.h>

void init_posix_file (Scheme_Env *env);
void init_posix_proc (Scheme_Env *env);

#endif
