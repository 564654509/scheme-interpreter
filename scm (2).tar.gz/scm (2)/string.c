/*
  Copyright (c) 2014 Xianfei Shen
  All rights reserved.

  Permission is hereby granted, without written agreement and without
  license or royalty fees, to use, copy, modify, and distribute this
  software and its documentation for any purpose, provided that the
  above copyright notice and the following two paragraphs appear in
  all copies of this software.
 
  IN NO EVENT SHALL BRENT BENSON BE LIABLE TO ANY PARTY FOR DIRECT,
  INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
  OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF BRENT
  BENSON HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

  BRENT BENSON SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT
  NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
  FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER
  IS ON AN "AS IS" BASIS, AND BRENT BENSON HAS NO OBLIGATION TO
  PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
  MODIFICATIONS.
*/

#include "string.h"

static scm_obj *create_str_obj(unsigned int len, char c)
{
	scm_obj *str_obj = scm_alloc_obj(sizeof(scm_obj));
	
	type(str_obj) = TYPE_STRING;
	len(str_obj) = len;
	str(str_obj) = scm_alloc_str(len + 1);
	
	for (unsigned int i = 0, char *p = str(str_obj);
	 	 i < len; ++i) {
		p[i] = c;
	}	
	p[i] = '\0';
	
	return str_obj;
}

/*  procedure: (make-string k) or (make-string k char)  */
scm_obj *str_make_string(const scm_obj *obj)
{
	if (obj == NIL) {
		error("expected: 1 to 2 arguments ==> make_string", obj);
	} else if (type(car(obj)) != TYPE_INTEGER) {
		error("expected: exact-nonnegative-integer ==> make_string", car(obj));
	} else if (fixnum(car(obj)) < 0) {
		error("expected: exact-nonnegative-integer ==> make_string", car(obj));
	} else if (cdr(obj) == NIL) {
		return create_str_obj(fixnum(car(obj)), '\0');
	} else if (type(cadr(obj)) != TYPE_CHAR) {
		error("expected: char ==> make_string", cadr(obj));
	} else if (cddr(obj) != NIL) {
		error("expected: 1 to 2 arguments ==> make_string", obj);
	} else {
		return create_str_obj(fixnum(car(obj)), Char(cadr(obj)));
	}		
}

/*  procedure: (string char ...)  */
scm_obj *str_cons_string(const scm_obj *obj)
{
	scm_obj *str_obj;
	unsigned int len = 0;
	
	for (scm_obj *p = obj; p != NIL;) {
		if (type(car(p)) != TYPE_CHAR) {
			error("expected: char ==> string", car(p));
		}
		p = cdr(p), ++len;
	}
	
	str_obj = scm_alloc_obj(sizeof(scm_obj));
	
	type(str_obj) = TYPE_STRING;
	len(str_obj) = len;
	str(str_obj) = scm_alloc_str(len + 1);
	
	for (unsigned int i = 0, char *p = str(str_obj),
	     scm_obj *q = obj; i < len;) {
	     p[i] = Char(car(q));
	     q = cdr(q), ++i;
	}
	
	return str_obj;
}

/*  procedure: (string-length string)  */
inline scm_obj *str_string_length(const scm_obj *obj)
{
	if (type(car(obj)) != TYPE_STRING) {
		error("expected: string ==> string_length", obj);
	} else {
		return make_integer(len(obj));
	}
}	

/*  procedure: (string-ref string k)  */
scm_obj *str_string_ref(const scm_obj *obj)
{
	if (type(car(obj)) != TYPE_STRING) {
		error("expected: string ==> string_ref", obj);
	} else if (cdr(obj) == NIL) {
		error("expected: 2 arguments ==> string_ref", obj);
	} else if (type(cadr(obj)) != TYPE_INTEGER || fixnum(cadr(obj))
			   < 0 || fixnum(cadr(obj)) >= len(obj)) {
		error("expected: a valid index of string ==> string_ref", obj);
	} else if (cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string_ref", obj);
	} else {
		return (str(car(obj)))[fixnum(cadr(obj))];
	}
}

/*  procedure: (string-set! string k char)  */
scm_obj *str_string_set(scm_obj *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj)
	    == NIL || cdddr(obj) != NIL) {
		error("expected: 3 arguments ==> string_set!", obj);
	} else if (type(car(obj)) != TYPE_STRING) {
		error("expected: string ==> string_set!", car(obj));
	} else if (type(cadr(obj)) != TYPE_INTEGER) {
		error("expected: nonnegative integer ==> string_set!", cadr(obj)); 
	} else if (fixnum(cadr(obj)) < 0 || fixnum(cadr(obj)) >= len(car(obj))) {
		error("expected: a valid index of string ==> string_set!", cadr(obj));
	} else if (type(caddr(obj)) != TYPE_CHAR) {
		error("expected: char ==> string_set!", caddr(obj));
	} else {
		(str(obj))[fixnum(cadr(obj))] = Char(caddr(obj));
	}
	
	return scheme_ok;
}

/*  procedure: (string? obj )  */
inline const scm_obj *str_pred_string(const scm_obj *obj)
{
	if (obj == NIL || cdr(obj) != NIL) {
		error("expected: 1 arguments ==> string?", obj);
	} else {
		return type(obj) == TYPE_STRING ? scheme_true : scheme_false;
	}
} 

/*  procedure: (string=? string1 string2)  */
inline const scm_obj *str_pred_string_eq(const scm_obj *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string=?", obj);
	} else if (type(car(obj)) != TYPE_STRING || type(cadr(obj)) != TYPE_STRING) {
		error("expected: string ==> string=?", obj);
	} else {
		return strcmp(str(car(obj)), str(cadr(obj))) == 0 ? scheme_true : scheme_false;
	}
}

/*  procedure: (string<=? string1 string2)  */
inline const scm_obj *str_pred_string_le(const scm_obj *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string<=?", obj);
	} else if (type(car(obj)) != TYPE_STRING || type(cadr(obj)) != TYPE_STRING) {
		error("expected: string ==> string<=?", obj);
	} else {
		return strcmp(str(car(obj)), str(cadr(obj))) <= 0 ? scheme_true : scheme_false;
	}
}

/*  procedure: (string<? string1 string2)  */
inline const scm_obj *str_pred_string_lt(const scm_obj *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string<?", obj);
	} else if (type(car(obj)) != TYPE_STRING || type(cadr(obj)) != TYPE_STRING) {
		error("expected: string ==> string<?", obj);
	} else {
		return strcmp(str(car(obj)), str(cadr(obj))) < 0 ? scheme_true : scheme_false;
	}
}

/*  procedure: (string>=? string1 string2)  */
inline const scm_obj *str_pred_string_ge(const scm_obj *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string>=?", obj);
	} else if (type(car(obj)) != TYPE_STRING || type(cadr(obj)) != TYPE_STRING) {
		error("expected: string ==> string>=?", obj);
	} else {
		return strcmp(str(car(obj)), str(cadr(obj))) >= 0 ? scheme_true : scheme_false;
	}
}

/*  procedure: (string>? string1 string2)  */
inline const scm_obj *str_pred_string_gt(const scm_obj *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string>?", obj);
	} else if (type(car(obj)) != TYPE_STRING || type(cadr(obj)) != TYPE_STRING) {
		error("expected: string ==> string>?", obj);
	} else {
		return strcmp(str(car(obj)), str(cadr(obj))) > 0 ? scheme_true : scheme_false;
	}
}

static scm_obj *upper_to_lower(const scm_obj *obj)
{
	for (char *p = str(obj); p != '\0'; ++p) {
		if (*p >= 'A' && *p <= 'Z') {
			*p += ('a' - 'A');
		}
	}
	
	return obj;
}

static scm_obj *lower_to_upper(const scm_obj *obj)
{
	for (char *p = str(obj); p != '\0'; ++p) {
		if (*p >= 'a' && *p <= 'z') {
			*p -= ('a' - 'A');
		}
	}
		
	return obj;
}

/*  procedure: (string-ci=? string1 string2)  */
const scm_obj *str_pred_string_ci_eq(const scm_obj *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string-ci=?", obj);
	} else if (type(car(obj)) != TYPE_STRING || type(cadr(obj)) != TYPE_STRING) {
		error("expected: string ==> string-ci=?", obj);
	} else {
		scm_obj *p = upper_to_lower(car(obj));
		scm_obj *q = upper_to_lower(cadr(obj));
		
		return strcmp(str(p), str(q)) == 0 ? scheme_true : scheme_false;
	}
}

/*  procedure: (string-ci<=? string1 string2)  */
const scm_obj *str_pred_string_ci_le(const scm_obj *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string-ci<=?", obj);
	} else if (type(car(obj)) != TYPE_STRING || type(cadr(obj)) != TYPE_STRING) {
		error("expected: string ==> string-ci<=?", obj);
	} else {
		scm_obj *p = upper_to_lower(car(obj));
		scm_obj *q = upper_to_lower(cadr(obj));
		
		return strcmp(str(p), str(q)) <= 0 ? scheme_true : scheme_false;
	}
}	

/*  procedure: (string-ci<? string1 string2)  */
const scm_obj *str_pred_string_ci_lt(const scm_obj *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string-ci<?", obj);
	} else if (type(car(obj)) != TYPE_STRING || type(cadr(obj)) != TYPE_STRING) {
		error("expected: string ==> string-ci<?", obj);
	} else {
		scm_obj *p = upper_to_lower(car(obj));
		scm_obj *q = upper_to_lower(cadr(obj));
		
		return strcmp(str(p), str(q)) < 0 ? scheme_true : scheme_false;
	}
}

/*  procedure: (string-ci>=? string1 string2)  */
const scm_obj *str_pred_string_ci_ge(const scm_obj *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string-ci>=?", obj);
	} else if (type(car(obj)) != TYPE_STRING || type(cadr(obj)) != TYPE_STRING) {
		error("expected: string ==> string-ci>=?", obj);
	} else {
		scm_obj *p = upper_to_lower(car(obj));
		scm_obj *q = upper_to_lower(cadr(obj));
		
		return strcmp(str(p), str(q)) >= 0 ? scheme_true : scheme_false;
	}
}

/*  procedure: (string-ci>? string1 string2)  */
const scm_obj *str_pred_string_ci_gt(const scm_obj *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 arguments ==> string-ci>?", obj);
	} else if (type(car(obj)) != TYPE_STRING || type(cadr(obj)) != TYPE_STRING) {
		error("expected: string ==> string-ci>?", obj);
	} else {
		scm_obj *p = upper_to_lower(car(obj));
		scm_obj *q = upper_to_lower(cadr(obj));
		
		return strcmp(str(p), str(q)) > 0 ? scheme_true : scheme_false;
	}
}

static scm_obj *make_string(const char *str)
{
	unsigned int len = strlen(str);
	scm_obj *str_obj;
	
	str_obj = scm_alloc_obj(sizeof(scm_obj));
	
    type(str_obj) = TYPE_STRING;
	len(str_obj) = len;
	str(str_obj) = scm_alloc_str(len + 1);
	strcpy(str(str_obj), str);
	
	return str_obj;
}

/* 	procedure: (substring start end)  */
scm_obj *str_substring(const scm_obj *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj)
		== NIL || cdddr(obj) != NIL) {
		error("expected: 3 arguments ==> substring", obj);
	} else if (type(car(obj)) != TYPE_STRING) {
		error("expected: string ==> substring", car(obj));
	} else if (type(cadr(obj)) != TYPE_INTEGER ||
			   type(caddr(obj)) != TYPE_INTEGER ||
			   fixnum(cadr(obj)) < 0 || fixnum(cadr(obj)) >= len(car(obj)) ||
			   fixnum(caddr(obj)) < 0 || fixnum(caddr(obj)) >= len(car(obj))) {
		error("expected: a valid index of string ==> substring", obj);
	} else {
		unsigned int len = fixnum(caddr(obj)) - fixnum(cadr(obj));
		if (len < 0) {
			error("expected: ending index is smaller than starting"
			      "index ==> substring", obj);
		}
					
		scm_obj *str_obj = scm_alloc_obj(sizeof(scm_obj));
		
		type(str_obj) = TYPE_STRING;
		len(str_obj) = len;
		str(str_obj) = scm_alloc_str(len + 1);
		strncpy(str(str_obj), str(obj) + fixnum(cadr(obj)), len);
		
		return str_obj;
	}
}

/*  procedure: (string-append string ...)  */
scm_obj *str_string_append(const scm_obj *obj)
{
	scm_obj *p = obj;
	scm_obj *str_obj;
	unsigned int len = 0;
	
	for (; p != NIL; p = cdr(p)) {
		if (type(car(p)) != TYPE_STRING) {
			error("expected: string ==> string-append", obj);
		}
		len += len(car(p));
	}
	
	str_obj = scm_alloc_obj(sizeof(scm_obj));
	
	type(str_obj) = TYPE_STRING;
	len(str_obj) = len;
	str(str_obj) = scm_alloc_str(len + 1);
	
	for (char *q = str(str_obj), p = obj; p != NIL;) {
		strcpy(q, str(car(p)));
		q += len(car(p));
		p = cdr(p);
	}
	*p = '\0';
	
	return str_obj;
}

/*  procedure: (string->list string)  */
scm_obj *str_string_to_list(const scm_obj *obj)
{
	if (obj == NIL || cdr(obj) != NIL) {
		error("expected: 1 argument ==> string->list", obj);
	} else if (type(car(obj)) != TYPE_STRING) {
		error("expected: string ==> string->list", car(obj));
	} else {
		unsigned int len = len(car(obj));
	}
}

/* 	procedure: (list->string list)  */
scm_obj *str_list_to_string(const scm_obj *obj)
{
	if (obj == NIL || cdr(obj) != NIL) {
		error("expected: 1 argument ==> list->string", obj);
	} else {
		const scm_obj *p = car(obj);
		unsigned int len = 0;
		
		while (p != NIL && type(p) == TYPE_PAIR) {
			if (type(car(p)) != TYPE_CHAR) {
				error("expected: list of char", obj);
			}
			p = cdr(p), ++len;
		}
		
		if (p != NIL) {
			error("expected: list of char", obj);
		} else {
			scm_obj *str_obj = scm_alloc_obj(sizeof(scm_obj));
			
			type(str_obj) = TYPE_STRING;
			len(str_obj) = len;
			str(str_obj) = scm_alloc_str(len + 1);
			
			for (len = 0, p = car(obj); p != NIL; p = cdr(p)) {
				(str(str_obj))[len++] = Char(car(p));
			}
			
			return str_obj;
		}
	}
}

/* 	procedure: (string-copy string)  */
scm_obj *str_string_copy(const scm_obj *obj)
{
	if (obj == NIL || cdr(obj) != NIL) {
		error("expected: 1 argument ==> string-copy", obj);
	} else if (type(car(obj)) != TYPE_STRING) {
		error("expected: string ==> string-copy", car(obj));
	} else {
		unsigned int len = len(car(obj));
		scm_obj *str_obj = scm_alloc_obj(sizeof(scm_obj));
		
		type(str_obj) = TYPE_STRING;
		len(str_obj) = len;
		str(str_obj) = scm_alloc_str(len + 1);
		strcpy(str(str_obj), str(obj));
				
		return str_obj;
	}
}

/* 	procedure: (string-fill! string char)  */		
scm_obj *str_string_fill(const scm_obj *obj)
{
	if (obj == NIL || cdr(obj) == NIL || cddr(obj) != NIL) {
		error("expected: 2 argument ==> string-fill!", obj);
	} else if (type(car(obj)) != TYPE_STRING) {
		error("expected: string ==> string-fill!", car(obj));
	} else if (type(cadr(obj)) != TYPE_CHAR) {
		error("expected: char ==> string-fill!", cadr(obj));
	} else {
		char *p = str(car(obj));
		const char c = Char(cadr(obj));
		
		for (unsigned int i = 0, len = len(car(obj)); 
			 i < len; i++) {
			 p[i] = c;
		}
		
		return scheme_ok;
	}
}

void scheme_init_string()
{
	scheme_add_prim("string?", str_pred_string);
	scheme_add_prim("make-string", str_make_string);
	scheme_add_prim("string", str_cons_string);
	scheme_add_prim("string-length", str_string_length);
	scheme_add_prim("string-ref", str_string_ref);
	scheme_add_prim("string-set!", str_string_set);
	scheme_add_prim("string=?", str_pred_string_eq);	
	scheme_add_prim("string<?", str_pred_string_lt);
	scheme_add_prim("string>?", str_pred_string_gt);
	scheme_add_prim("string<=?", str_pred_string_le);
	scheme_add_prim("string>=?", str_pred_string_ge);
	scheme_add_prim("string-ci=?", str_pred_string_ci_eq);
	scheme_add_prim("string-ci<?", str_pred_string_ci_lt);
	scheme_add_prim("string-ci>?", str_pred_string_ci_gt);
	scheme_add_prim("string-ci<=?", str_pred_string_ci_le);
	scheme_add_prim("string-ci>=?", str_pred_string_ci_ge);
	scheme_add_prim("substring", str_substring);
	scheme_add_prim("string-append", str_string_append);
	scheme_add_prim("string->list", str_string_to_list);
	scheme_add_prim("list->string", str_list_to_string);
	scheme_add_prim("string-copy", str_string_copy);
	scheme_add_prim("string-fill!", str_string_fill);
}

			








																		 
		
